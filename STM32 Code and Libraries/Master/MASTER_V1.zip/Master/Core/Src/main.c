/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "dynamixel.h"
#include "lidar.h"
#include <string.h>
#include <stdio.h>
#include <memory.h>
#include <stdlib.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define Slave1ID    0x031
#define MasterID    0x030

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;

osThreadId RxUSARTHandle;
osThreadId SendCANHandle;
osThreadId ReceiveCANHandle;
osThreadId LEDHandle;
osThreadId SendUSARTHandle;
osMessageQId USART_QueueHandle;
osMessageQId SendUSART_QueueHandle;
osMessageQId CANRx_QueueHandle;
osSemaphoreId BinSem_NewUsartHandle;
osSemaphoreId BinSem_CAN_RXHandle;
osSemaphoreId BinSem_ConfigReadyHandle;
osSemaphoreId BinSem_USARTReadyHandle;
osSemaphoreId CntSem_NewCANHandle;
/* USER CODE BEGIN PV */
CAN_RxHeaderTypeDef rxHeader; //CAN Bus Transmit Header
CAN_TxHeaderTypeDef txHeader; //CAN Bus Receive Header
CAN_FilterTypeDef canfil; //CAN Bus Filter
uint32_t canMailbox; //CAN Bus Mail box variable
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_CAN_Init(void);
void RxUSART_Task(void const * argument);
void SendDataCAN(void const * argument);
void ReceiveDataCAN(void const * argument);
void LEDBlink(void const * argument);
void SendUSART_Task(void const * argument);

/* USER CODE BEGIN PFP */
uint8_t CAN_Send_Msg(uint8_t* CAN_msg, uint8_t CAN_datalen, uint8_t std_id);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

typedef struct ConfigsData{
	uint16_t angle_init;
	uint16_t angle_end;
	uint16_t step;
	uint16_t frequency;
}ConfigsData;

typedef struct RxCAN_Data{
    uint16_t dist;            // Distância (2 Bytes)
    uint16_t angle;            // Angulo (2 Bytes)
    TickType_t time;        // Tempo (4 Bytes)
    uint16_t temp;            // Temperatura (2 Bytes)
    uint16_t stre;            // Força (2 Bytes)
}RxCAN_Data;

//----------------------------------------- CAN -----------------------------------------
// Interrupt Rx CAN

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan)
{

	uint8_t canRX[8],i;
	static BaseType_t pxHigherPriorityTaskWoken;

	HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &rxHeader, canRX); //Receive CAN bus message
	for (i = 0; i < rxHeader.DLC; ++i) {
		xQueueGenericSendFromISR(CANRx_QueueHandle, &canRX[i], 10, queueSEND_TO_BACK);
	}
	osSemaphoreRelease(BinSem_CAN_RXHandle);
	if( pxHigherPriorityTaskWoken == 1 ){
		osThreadYield(); /* forces the context change */
	}


}
//----------------------------------------- CAN -----------------------------------------

// Interrupt Rx USART
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){

	static BaseType_t pxHigherPriorityTaskWoken;

    if (huart->Instance == USART1){
       osSemaphoreRelease(BinSem_NewUsartHandle);
    }
    if( pxHigherPriorityTaskWoken == 1 ){
    		osThreadYield(); /* forces the context change */
	}
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART1_UART_Init();
  MX_USART3_UART_Init();
  MX_CAN_Init();
  /* USER CODE BEGIN 2 */


  /* USER CODE END 2 */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* definition and creation of BinSem_NewUsart */
  osSemaphoreDef(BinSem_NewUsart);
  BinSem_NewUsartHandle = osSemaphoreCreate(osSemaphore(BinSem_NewUsart), 1);

  /* definition and creation of BinSem_CAN_RX */
  osSemaphoreDef(BinSem_CAN_RX);
  BinSem_CAN_RXHandle = osSemaphoreCreate(osSemaphore(BinSem_CAN_RX), 1);

  /* definition and creation of BinSem_ConfigReady */
  osSemaphoreDef(BinSem_ConfigReady);
  BinSem_ConfigReadyHandle = osSemaphoreCreate(osSemaphore(BinSem_ConfigReady), 1);

  /* definition and creation of BinSem_USARTReady */
  osSemaphoreDef(BinSem_USARTReady);
  BinSem_USARTReadyHandle = osSemaphoreCreate(osSemaphore(BinSem_USARTReady), 1);

  /* definition and creation of CntSem_NewCAN */
  osSemaphoreDef(CntSem_NewCAN);
  CntSem_NewCANHandle = osSemaphoreCreate(osSemaphore(CntSem_NewCAN), 2);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  osSemaphoreWait(CntSem_NewCANHandle, osWaitForever);
  osSemaphoreWait(CntSem_NewCANHandle, osWaitForever);
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* definition and creation of USART_Queue */
  osMessageQDef(USART_Queue, 10, uint16_t);
  USART_QueueHandle = osMessageCreate(osMessageQ(USART_Queue), NULL);

  /* definition and creation of SendUSART_Queue */
  osMessageQDef(SendUSART_Queue, 2, RxCAN_Data);
  SendUSART_QueueHandle = osMessageCreate(osMessageQ(SendUSART_Queue), NULL);

  /* definition and creation of CANRx_Queue */
  osMessageQDef(CANRx_Queue, 16, uint8_t);
  CANRx_QueueHandle = osMessageCreate(osMessageQ(CANRx_Queue), NULL);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* definition and creation of RxUSART */
  osThreadDef(RxUSART, RxUSART_Task, osPriorityBelowNormal, 0, 128);
  RxUSARTHandle = osThreadCreate(osThread(RxUSART), NULL);

  /* definition and creation of SendCAN */
  osThreadDef(SendCAN, SendDataCAN, osPriorityAboveNormal, 0, 256);
  SendCANHandle = osThreadCreate(osThread(SendCAN), NULL);

  /* definition and creation of ReceiveCAN */
  osThreadDef(ReceiveCAN, ReceiveDataCAN, osPriorityIdle, 0, 256);
  ReceiveCANHandle = osThreadCreate(osThread(ReceiveCAN), NULL);

  /* definition and creation of LED */
  osThreadDef(LED, LEDBlink, osPriorityIdle, 0, 128);
  LEDHandle = osThreadCreate(osThread(LED), NULL);

  /* definition and creation of SendUSART */
  osThreadDef(SendUSART, SendUSART_Task, osPriorityNormal, 0, 256);
  SendUSARTHandle = osThreadCreate(osThread(SendUSART), NULL);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {

  }
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI_DIV2;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN_Init(void)
{

  /* USER CODE BEGIN CAN_Init 0 */

  /* USER CODE END CAN_Init 0 */

  /* USER CODE BEGIN CAN_Init 1 */

  /* USER CODE END CAN_Init 1 */
  hcan.Instance = CAN1;
  hcan.Init.Prescaler = 8;
  hcan.Init.Mode = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1 = CAN_BS1_3TQ;
  hcan.Init.TimeSeg2 = CAN_BS2_4TQ;
  hcan.Init.TimeTriggeredMode = DISABLE;
  hcan.Init.AutoBusOff = DISABLE;
  hcan.Init.AutoWakeUp = DISABLE;
  hcan.Init.AutoRetransmission = DISABLE;
  hcan.Init.ReceiveFifoLocked = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN_Init 2 */

	canfil.FilterBank = 0;
	canfil.FilterMode = CAN_FILTERMODE_IDLIST;
	canfil.FilterFIFOAssignment = CAN_RX_FIFO0;
	canfil.FilterIdHigh = Slave1ID<<5;
	canfil.FilterIdLow = 0;
	canfil.FilterMaskIdHigh = 0;
	canfil.FilterMaskIdLow = 0;
	canfil.FilterScale = CAN_FILTERSCALE_32BIT;
	canfil.FilterActivation = ENABLE;
	canfil.SlaveStartFilterBank = 14;

	HAL_CAN_ConfigFilter(&hcan,&canfil); //Initialize CAN Filter
	HAL_CAN_Start(&hcan); //Initialize CAN Bus
	HAL_CAN_ActivateNotification(&hcan,CAN_IT_RX_FIFO0_MSG_PENDING);// Initialize CAN Bus Rx Interrupt

  /* USER CODE END CAN_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */

  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 57600;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, statusLED_Pin|LD2_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_0|GPIO_PIN_12, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(Dir485_GPIO_Port, Dir485_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : B1_Pin */
  GPIO_InitStruct.Pin = B1_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(B1_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : statusLED_Pin LD2_Pin */
  GPIO_InitStruct.Pin = statusLED_Pin|LD2_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : PB0 PB12 */
  GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_12;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /*Configure GPIO pin : Dir485_Pin */
  GPIO_InitStruct.Pin = Dir485_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(Dir485_GPIO_Port, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

}

/* USER CODE BEGIN 4 */

//----------------------------------------- CAN CODE -----------------------------------------

uint8_t CAN_Send_Msg(uint8_t* CAN_msg, uint8_t CAN_datalen, uint8_t std_id)
{
  CAN_TxHeaderTypeDef TxHeader;			//CAN Bus Receive Header
  uint32_t canMailbox; 					//CAN Bus Mail box variable

  TxHeader.StdId = std_id;		// ID of this CAN network node
  TxHeader.ExtId = 0x00;
  TxHeader.IDE = CAN_ID_STD;	// Standard ID (11 bits)
  TxHeader.RTR = CAN_RTR_DATA;	// Tranmitt data
  TxHeader.DLC = CAN_datalen;	// Number of bites to be transmitted max- 8
  TxHeader.TransmitGlobalTime = ENABLE;
  while(HAL_CAN_GetTxMailboxesFreeLevel(&hcan)==0);
  if(HAL_CAN_AddTxMessage(&hcan, &TxHeader, CAN_msg, &canMailbox) != HAL_OK){	//Send CAN Message
    return pdFAIL;
  }
    return pdPASS ;
}

//----------------------------------------- CAN CODE -----------------------------------------

/* USER CODE END 4 */

/* USER CODE BEGIN Header_RxUSART_Task */
/**
  * @brief  Function implementing the RxUSART thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_RxUSART_Task */
void RxUSART_Task(void const * argument)
{
  /* USER CODE BEGIN 5 */
	 uint8_t config=0,i;
	char uartChar, uartBuffer[8];
	uint16_t data;

	HAL_UART_Receive_IT(&huart1, &uartChar, 1);
	osSemaphoreWait(BinSem_NewUsartHandle, osWaitForever);
	/* Infinite loop */
	for(;;)
	{

	  osSemaphoreWait(BinSem_NewUsartHandle, osWaitForever);

	  HAL_UART_Receive_IT(&huart1, &uartChar, 1);

	  if(uartChar == ','){
		if (config==1)
		{
			data = atoi(uartBuffer);
			xQueueGenericSend(USART_QueueHandle,&data , 10, queueSEND_TO_BACK);
			memset(uartBuffer, 0, sizeof(uartBuffer));
			  i=0;
		}

	  }
	  else{
		  uartBuffer[i] = uartChar;
		  i++;
	  }

	  if(uartChar == '/'){
		  memset(uartBuffer, 0, sizeof(uartBuffer));

		  if(config==0){
			  config=1;
		  }
		  else{
			  config=0;
			  if(uxQueueMessagesWaiting(USART_QueueHandle)>=5){
				  osSemaphoreRelease(BinSem_ConfigReadyHandle);

			  }

		  }

		  i=0;
	  }
	}
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_SendDataCAN */
/**
* @brief Function implementing the SendCAN thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_SendDataCAN */
void SendDataCAN(void const * argument)
{
  /* USER CODE BEGIN SendDataCAN */
  uint8_t i,canTX[] = {0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00};  // Tx Buffer
  uint16_t data;
  uint16_t ID_value;
  //uint16_t ID_value2;
  char buffer[32];
  osSemaphoreWait(BinSem_ConfigReadyHandle, osWaitForever);
  /* Infinite loop */
  for(;;)
  {

    osSemaphoreWait(BinSem_ConfigReadyHandle, osWaitForever);


    for (i = 0; i < 8; i+=2) {
		xQueueReceive(USART_QueueHandle, &data, 10);
		canTX[i] = data >> 8;
		canTX[i+1] = data & 0x00FF;
	}
    ID_value = (xQueueReceive(USART_QueueHandle, &data, 10)>>8) + (xQueueReceive(USART_QueueHandle, &data, 10) & 0x00FF);

    //sprintf(buffer,"/%u,%u,%u,%u,%u,%u,%u,%u,%lu,/",canTX[0],canTX[1],canTX[2],canTX[3],canTX[4],canTX[5],canTX[6],canTX[7],ID_value);
	//HAL_UART_Transmit(&huart1, buffer, strlen (buffer), HAL_MAX_DELAY);
    if (CAN_Send_Msg(canTX,8,ID_value) != pdPASS){
    	char *str = "CAN Message send ERROR\r\n";
		HAL_UART_Transmit(&huart1, (uint8_t *)str, strlen (str), HAL_MAX_DELAY);
    }

  }
  /* USER CODE END SendDataCAN */
}

/* USER CODE BEGIN Header_ReceiveDataCAN */
/**
* @brief Function implementing the ReceiveCAN thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_ReceiveDataCAN */
void ReceiveDataCAN(void const * argument)
{
  /* USER CODE BEGIN ReceiveDataCAN */
  RxCAN_Data CANdata;
  uint8_t canRX[8],i;
  char Buffer[64];


  /* Infinite loop */
  for(;;)
  {

	  osSemaphoreWait(BinSem_CAN_RXHandle, osWaitForever);
	  for (i = 0; i < rxHeader.DLC; ++i) {
	  		xQueueReceiveFromISR(CANRx_QueueHandle, &canRX[i], 10);
	  	}

	//HAL_UART_Transmit(&huart1, Buffer, strlen (Buffer), HAL_MAX_DELAY);
	if(rxHeader.DLC==8){
		CANdata.dist = canRX[0] << 8 | canRX[1];
		CANdata.angle = canRX[2] << 8 | canRX[3];
		CANdata.time = canRX[4] << 24 | canRX[5] << 16 | canRX[6] << 8 | canRX[7];

		if(osSemaphoreGetCount(CntSem_NewCANHandle)==0){
			osSemaphoreRelease(CntSem_NewCANHandle);
		}

	}

	if(rxHeader.DLC==4){
		CANdata.stre = canRX[0] << 8 | canRX[1];
		CANdata.temp = canRX[2] << 8 | canRX[3];

		if(osSemaphoreGetCount(CntSem_NewCANHandle)==1){
				osSemaphoreRelease(CntSem_NewCANHandle);
			}
	}


	if (osSemaphoreGetCount(CntSem_NewCANHandle)==2){


		xQueueGenericSend(SendUSART_QueueHandle, &CANdata, 10, queueSEND_TO_BACK);

		osSemaphoreRelease(BinSem_USARTReadyHandle);

		osSemaphoreWait(CntSem_NewCANHandle, osWaitForever);
		osSemaphoreWait(CntSem_NewCANHandle, osWaitForever);

	}

  }
  /* USER CODE END ReceiveDataCAN */
}

/* USER CODE BEGIN Header_LEDBlink */
/**
* @brief Function implementing the LED thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_LEDBlink */
void LEDBlink(void const * argument)
{
  /* USER CODE BEGIN LEDBlink */
  /* Infinite loop */
  for(;;)
  {
    osDelay(500);
    HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_0);
  }
  /* USER CODE END LEDBlink */
}

/* USER CODE BEGIN Header_SendUSART_Task */
/**
* @brief Function implementing the SendUSART thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_SendUSART_Task */
void SendUSART_Task(void const * argument)
{
  /* USER CODE BEGIN SendUSART_Task */
	char buffer[64];

	RxCAN_Data CANdata;
	osSemaphoreWait(BinSem_USARTReadyHandle, osWaitForever);
  /* Infinite loop */
  for(;;)
  {
    osSemaphoreWait(BinSem_USARTReadyHandle, osWaitForever);
    xQueueReceive(SendUSART_QueueHandle, &CANdata, 10);
    sprintf(buffer, "/%u,%u,%lu,%u,%u,%u,/",CANdata.dist,CANdata.angle,CANdata.time, CANdata.stre, CANdata.temp,rxHeader.StdId);
    HAL_UART_Transmit(&huart1, buffer, strlen (buffer), osWaitForever);


  }
  /* USER CODE END SendUSART_Task */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM4 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM4) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
